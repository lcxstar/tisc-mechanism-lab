tisc -Q2nd_example_load.xyp -N101 -D-2.5e5/2.5e5/-2.5e5/2.5e5 -qmode_interp=4
